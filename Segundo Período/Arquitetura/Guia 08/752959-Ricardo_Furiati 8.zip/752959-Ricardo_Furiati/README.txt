Aluno: Ricardo Henrique Guedes Furiati
Matrícula: 752959
Curso: Ciência da Computação - Manhã 
Disciplina: Arquitetura de Computadores

Na pasta "Circuitos" encontram-se os circuitos desenvolvidos das questões 1 a 5.
Em cada arquivo .circ correspondente a uma questão encontram-se o circuito principal e subcircuitos desenvolvidos.
No arquivo "Tabela Verdade.txt" encontram-se as tabelas verdade utilizadas para o desenvolvimento da questão 1 e 2
O desenvolvimento das questões em verilog encontra-se incompleto em relação ao display dos resultados obtidos :(

